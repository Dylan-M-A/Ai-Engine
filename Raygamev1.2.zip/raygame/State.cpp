#include "State.h"

AIForGames::State::State()
{
}

AIForGames::State::~State()
{
}

void AIForGames::State::AddTransition(Condition* condition, State* targetState)
{
}

void AIForGames::State::Enter(Agent* agent)
{
}

void AIForGames::State::Update(Agent* agent, float deltaTime)
{
}

void AIForGames::State::Exit(Agent* agent)
{
}
