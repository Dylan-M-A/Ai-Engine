enum State
{
	RUNNER,
	WALKER,
	CHASER
};

